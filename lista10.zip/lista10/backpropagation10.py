from itertools import product

# Dados de entrada: 2^10 = 1024 combinações
X10 = np.array(list(product([0, 1], repeat=10)))
Y_AND_10 = np.array([1 if sum(x) == 10 else 0 for x in X10])
Y_OR_10  = np.array([1 if sum(x) > 0 else 0 for x in X10])
Y_XOR_10 = np.array([1 if sum(x) % 2 == 1 else 0 for x in X10])

def build_model_10(activation='sigmoid', learning_rate=0.1, use_bias=True):
    model = Sequential([
        Dense(16, input_dim=10, activation=activation, use_bias=use_bias),
        Dense(8, activation=activation, use_bias=use_bias),
        Dense(1, activation='sigmoid', use_bias=use_bias)
    ])
    model.compile(optimizer=SGD(learning_rate=learning_rate),
                  loss='binary_crossentropy',
                  metrics=['accuracy'])
    return model

def train_and_evaluate_10(X, y, title, **kwargs):
    print(f"--- {title} ---")
    model = build_model_10(**kwargs)
    model.fit(X, y, epochs=100, batch_size=32, verbose=0)
    loss, acc = model.evaluate(X, y, verbose=0)
    print(f"Acurácia final: {acc:.4f}")
    print()

# Experimentos
train_and_evaluate_10(X10, Y_AND_10, "AND 10 bits (sigmoide, com bias)")
train_and_evaluate_10(X10, Y_OR_10,  "OR  10 bits (sigmoide, com bias)")
train_and_evaluate_10(X10, Y_XOR_10, "XOR 10 bits (sigmoide, com bias)")
train_and_evaluate_10(X10, Y_XOR_10, "XOR 10 bits (ReLU, com bias)", activation='relu')
train_and_evaluate_10(X10, Y_XOR_10, "XOR 10 bits (sigmoide, sem bias)", use_bias=False)
train_and_evaluate_10(X10, Y_XOR_10, "XOR 10 bits (sigmoide, lr=0.01)", learning_rate=0.01)
