from itertools import product

# Gerar todas as combinações de 10 bits
X_10 = np.array(list(product([0, 1], repeat=10)))

# Saídas desejadas
Y_AND_10 = np.array([1 if sum(x) == 10 else 0 for x in X_10])
Y_OR_10  = np.array([1 if sum(x) > 0 else 0 for x in X_10])
Y_XOR_10 = np.array([1 if sum(x) % 2 == 1 else 0 for x in X_10])

# Treinamento e avaliação
def evaluate(model, X, y, name):
    correct = 0
    for xi, target in zip(X, y):
        pred = model.predict(xi)
        correct += int(pred == target)
    acc = correct / len(X)
    print(f"{name} - Acurácia: {acc:.4f}")

# AND
p10_and = Perceptron(n_inputs=10, epochs=20)
p10_and.train(X_10, Y_AND_10)
evaluate(p10_and, X_10, Y_AND_10, "Perceptron 10 entradas - AND")

# OR
p10_or = Perceptron(n_inputs=10, epochs=20)
p10_or.train(X_10, Y_OR_10)
evaluate(p10_or, X_10, Y_OR_10, "Perceptron 10 entradas - OR")

# XOR (falha esperada)
p10_xor = Perceptron(n_inputs=10, epochs=20)
p10_xor.train(X_10, Y_XOR_10)
evaluate(p10_xor, X_10, Y_XOR_10, "Perceptron 10 entradas - XOR")
