import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD
import numpy as np

# Dados de entrada
X2 = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])

Y_AND = np.array([0, 0, 0, 1])
Y_OR  = np.array([0, 1, 1, 1])
Y_XOR = np.array([0, 1, 1, 0])

def build_model(activation='sigmoid', learning_rate=0.1, use_bias=True):
    model = Sequential([
        Dense(4, input_dim=2, activation=activation, use_bias=use_bias),
        Dense(1, activation='sigmoid', use_bias=use_bias)
    ])
    model.compile(optimizer=SGD(learning_rate=learning_rate),
                  loss='binary_crossentropy',
                  metrics=['accuracy'])
    return model

def train_and_evaluate(X, y, title, **kwargs):
    print(f"--- {title} ---")
    model = build_model(**kwargs)
    model.fit(X, y, epochs=200, verbose=0)
    loss, acc = model.evaluate(X, y, verbose=0)
    print(f"Acurácia final: {acc:.4f}")
    preds = model.predict(X).round().astype(int).flatten()
    for xi, yi, pi in zip(X, y, preds):
        print(f"Entrada: {xi} -> Esperado: {yi} | Predito: {pi}")
    print()

# Testes padrão com sigmoide e bias
train_and_evaluate(X2, Y_AND, "AND (sigmoide, com bias)")
train_and_evaluate(X2, Y_OR,  "OR  (sigmoide, com bias)")
train_and_evaluate(X2, Y_XOR, "XOR (sigmoide, com bias)")

# Comparações com diferentes condições
train_and_evaluate(X2, Y_XOR, "XOR (ReLU, com bias)", activation='relu')
train_and_evaluate(X2, Y_XOR, "XOR (sigmoide, sem bias)", use_bias=False)
train_and_evaluate(X2, Y_XOR, "XOR (sigmoide, lr=0.01)", learning_rate=0.01)
