import numpy as np
import matplotlib.pyplot as plt

def step(x):
    return 1 if x >= 0 else 0

class Perceptron:
    def __init__(self, n_inputs, learning_rate=0.1, epochs=10):
        self.weights = np.zeros(n_inputs)
        self.bias = 0
        self.lr = learning_rate
        self.epochs = epochs

    def predict(self, x):
        total = np.dot(self.weights, x) + self.bias
        return step(total)

    def train(self, X, y):
        for epoch in range(self.epochs):
            for xi, target in zip(X, y):
                pred = self.predict(xi)
                error = target - pred
                self.weights += self.lr * error * xi
                self.bias += self.lr * error

    def plot_decision_boundary(self, X, y, title):
        for xi, label in zip(X, y):
            color = 'blue' if label == 0 else 'red'
            plt.scatter(xi[0], xi[1], c=color)

        x_vals = np.linspace(-0.5, 1.5, 100)
        y_vals = -(self.weights[0] * x_vals + self.bias) / self.weights[1]
        plt.plot(x_vals, y_vals, '--k')
        plt.title(title)
        plt.xlabel("x1")
        plt.ylabel("x2")
        plt.grid(True)
        plt.show()

# Dados de entrada
X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])

# Funções alvo
Y_AND = np.array([0, 0, 0, 1])
Y_OR = np.array([0, 1, 1, 1])
Y_XOR = np.array([0, 1, 1, 0])

# Treinamento
p_and = Perceptron(n_inputs=2)
p_and.train(X, Y_AND)
p_and.plot_decision_boundary(X, Y_AND, "Perceptron - Função AND")

p_or = Perceptron(n_inputs=2)
p_or.train(X, Y_OR)
p_or.plot_decision_boundary(X, Y_OR, "Perceptron - Função OR")

p_xor = Perceptron(n_inputs=2)
p_xor.train(X, Y_XOR)
p_xor.plot_decision_boundary(X, Y_XOR, "Perceptron - Função XOR (Falha esperada)")
